# Setting up connection with MongoDB
db_url = "mongodb://localhost:27017/"
