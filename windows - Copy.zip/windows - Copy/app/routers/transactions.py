from fastapi import APIRouter
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
import json
from bson import json_util
from bson.objectid import ObjectId
from pymongo import MongoClient
from app.db.db import db_url
from app.check.checkModel import dict_compare,flatten_dict
from fastapi.templating import Jinja2Templates


router = APIRouter()
templates = Jinja2Templates(directory="templates")

# Setting up connection with MongoDB
client = MongoClient(db_url)
database = client["feedbackLoop"]
inputModel = database["inputObjectModel"] 
inputTransaction = database["inputTransaction"] 

@router.get("/transactinos/", tags=["transactions"])
async def read_transactions():
    return [{"username": "Rick"}, {"username": "Morty"}]


@router.get("/transactinos/{transactionId}", tags=["transactions"])
async def read_transaction(objectModelId: str, request: Request):
    return [{"username": "Rick"}, {"username": "Morty"}]