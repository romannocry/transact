import sys
 
 
print("User Current Version:-", sys.version)