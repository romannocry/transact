var ws = new WebSocket("ws://localhost:8000/sendVote");
/**
Function will be called on clicking vote button from pizzaVsburger.html
*/
function myVote(voteTo) {
    var vote = voteTo === 'pizza' ? 0 : 1;
    pollingChart.data.datasets[0].data[vote] += 1;
    pollingChart.update();
    sendMessage(voteTo);
}

/**
Function will send the vote to server by using websocket.
*/
function sendMessage(votedTo) {
    ws.send(votedTo);
    event.preventDefault();
}