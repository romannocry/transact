from typing import Optional
from fastapi import FastAPI, WebSocket
from fastapi import Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from pymongo import MongoClient


#app initialization
app = FastAPI()
ws = app.websocket

html = """
<!DOCTYPE html>
<html>
    <head>
        <title>Chat</title>
    </head>
    <body>
        <h1>WebSocket Chat</h1>
        <form action="" onsubmit="sendMessage(event)">
            <input type="text" id="messageText" autocomplete="off"/>
            <button>Send</button>
        </form>
        <ul id='messages'>
        </ul>
        <script>
            var ws = new WebSocket("ws://localhost:8000/ws");
            ws.onmessage = function(event) {
                var messages = document.getElementById('messages')
                var message = document.createElement('li')
                var content = document.createTextNode(event.data)
                message.appendChild(content)
                messages.appendChild(message)
            };
            function sendMessage(event) {
                var input = document.getElementById("messageText")
                ws.send(input.value)
                input.value = ''
                event.preventDefault()
            }
        </script>
    </body>
</html>
"""

# Setting up connection with MongoDB
client = MongoClient("mongodb://localhost:27017/")
database = client["pizzaVsburger"]
# database's table which stores the user votes.
collection = database["votes"] 

class Item(BaseModel):
    name: str
    price: float
    is_offer: Optional[bool] = None

# Templates directory, in which our html & javascript files are stored.
#templates = Jinja2Templates(directory="templates")
#app.mount("/templates", StaticFiles(directory="templates", html=True), name="templates")
# API which returns HTML file as response.
#@app.websocket("/test")
#async def get(request: Request):
    # Here in list 1 represent pizza's vote & 0 represents burger's.
#    votes = [1,0]
#    return {'o'}#templates.TemplateResponse("pizzaVsburger.html", {'request': request, 'votes':'' })

#@app.get("/")
#async def root():
#    return {"message": "Hello World"}

@app.get("/")
def read_root(request: Request):
# def read_root():
    #return {"Hello": "World"}
    #return templates.TemplateResponse("pizzaVsburger.html", {"request": request})
    return HTMLResponse(html)


# def read_root():
    #return {"Hello": "World"}
    return templates.TemplateResponse("pizzaVsburger.html", {"request": request})

@app.get("/items/{item_id}")
def read_item(item_id: int, q: Optional[str] = None):
#async def read_item(item_id: int, q: Optional[str] = None):
    return {"item_id": item_id, "q": q}

@app.put("/items/{item_id}")
def update_item(item_id: int, item: Item):
    return {"item_name": item.name, "item_id": item_id}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = await websocket.receive_text()
        await websocket.send_text(f"Message text was: {data}")