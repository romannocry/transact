from asyncio.windows_events import NULL
from tkinter.tix import INTEGER
from typing import List
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pymongo import MongoClient
from bson.objectid import ObjectId
import uvicorn
import base64
import json
import random
import logging, platform
import time
import io
from starlette.responses import StreamingResponse
import socket
from starlette.middleware.cors import CORSMiddleware
from jinja2_base64_filters import jinja2_base64_filters
from enum import Enum
from datetime import date,datetime,timedelta
from enum import Enum
from fastapi.responses import JSONResponse
import bson
from pydantic import BaseModel
from starlette.requests import Request
from starlette.responses import Response

#correct: {"SMC":"IDX","price":6,"rating":1}
#eyJTTUMiOiJJRFgiLCJwcmljZSI6NiwicmF0aW5nIjoxfQ==
#incorrect - wrong type for rating: {"SMC":"IDX","price":6,"rating":"1"}
#eyJTTUMiOiJJRFgiLCJwcmljZSI6NiwicmF0aW5nIjoiMSJ9
#incorrect - payload missing rating: {"SMC":"IDX","price":6}
#eyJTTUMiOiJJRFgiLCJwcmljZSI6Nn0=
#semi-correct - payload containing another attribute: {"SMC":"IDX","price":6,"rating":1,"blob":"blob"}
#eyJTTUMiOiJJRFgiLCJwcmljZSI6NiwicmF0aW5nIjoxLCJibG9iIjoiYmxvYiJ9
#eyJTTUMiOiJJRFgiLCJwcmljZSI6NiwicmF0aW5nIjo1LCJibG9iIjoiYmxvYiJ9

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_personal_message(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)


manager = ConnectionManager()

class User(BaseModel):
    username: str
    email: str


loggedInUser = {}

fake_users_db = {
    "johndoe": {
        "username": "johndoe",
        "full_name": "John Doe",
        "email": "johndoe@example.com",
        "hashed_password": "fakehashedsecret",
    },
    "alice": {
        "username": "alice",
        "full_name": "Alice Wonderson",
        "email": "alice@example.com",
        "hashed_password": "fakehashedsecret2",
    },
    "roman": {
        "username": "roman",
        "full_name": "Roman medioni",
        "email": "roman@example.com",
        "hashed_password": "fakehashedsecret2",
    },
}

class UnicornException(Exception):
    def __init__(self, name: str, label: str):
        self.name = name
        self.label = label

app = FastAPI()
#if __name__ == "__main__":
#    uvicorn.run("main:app", host="0.0.0.0", port=8000, log_level="info")

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="screens")

# Setting up connection with MongoDB
client = MongoClient("mongodb://localhost:27017/")
database = client["feedbackLoop"]
inputModel = database["inputObjectModel"] 
inputTransaction = database["inputTransaction"] 

@app.exception_handler(UnicornException)
async def unicorn_exception_handler(request: Request, exc: UnicornException):
    return JSONResponse(
        status_code=500,
        content={"message": f"Oops! {exc.name} did something: {exc.label}"},
    )

@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    
    start_time = time.time()
    #time.sleep(5)
    #get user
    loggedInUser['id']=2
    loggedInUser['username']="roman"
    loggedInUser['email']="roman.medioni@gmail.com"
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    response.headers["user"] = str(loggedInUser)
    return response


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["DELETE", "GET", "POST", "PUT"],
    allow_headers=["*"],
)


@app.get("/{name}")
def welcome(name: str):
    return f"Welcome {name}"

@app.get("/insertObjectModel/{payload}")
def insertObjectModelViaGet(payload: str, request: Request):
    _id = inputModel.insert_one({
        'object_creation_date': datetime.now(),
        'object_modification_date': datetime.now(),
        'object_created_by': loggedInUser,
        'object_modified_by': loggedInUser,
        'object_name':payload,
        'object_model':{
            'SMC':{'label':'SMC','values':['IDX','FSI']},
            'price':{'label':'price','values':'int'},
            'rating':{'label':'rating','values':[1,2,3,4,5]},
        },
        'allow_change':{
            'value':True,
            'before':datetime.now()+timedelta(days=1)
        },
        'allow_multiple':{
            'value':False,
            'frequency':'daily'
        }
        
        
        }).inserted_id
    return f"Model persisted via get under id: {_id}"

@app.post("/insertObjectModel/{model}")
def insertObjectModelViaPost(model: str, request: Request):
    return model    


@app.get("/sgconnect/insertTransaction/{objectModelId}/{payload}")
def insertTransactionViaBrowser(objectModelId: str, payload: str, request: Request):
    return templates.TemplateResponse("authenticate.html", {"request": request, "objectModelId":objectModelId, "payload":payload})

@app.post("/insertTransaction/{objectModelId}/{payload}")
async def insertTransaction(objectModelId: str, payload: str, request: Request):
  
    userP = await request.json()
    print(userP)
    loggedInUser['id']=userP['id']
    loggedInUser['username']=userP['username']
    loggedInUser['email']=userP['email']
    #get template model but make sure it is a valide object id
    if bson.objectid.ObjectId.is_valid(objectModelId):
        inputModelQuery = inputModel.find_one({"_id": ObjectId(objectModelId)})
        if inputModelQuery is None: raise UnicornException(name=objectModelId,label="ObjectModelId does not exist!")
        else: 
            #The model id exist so we try to decode the payload
            try:    
                payload_base64_decode = base64.b64decode(payload)
                payload_to_dict = json.loads(payload_base64_decode)
            except Exception as e:
                raise UnicornException(name=payload,label="invalid payload, not a b64 string")

            userObj = loggedInUser
            #checking if transaction existing for this object model and user
            transaction = inputTransaction.find_one({"objectModelId":ObjectId(objectModelId),"user.id":loggedInUser['id']})
            if bool(transaction):
                #transaction.pop("_id")
                #transaction.pop("objectModelId")
                #if transaction already exists, the model might allow modification (allow_change) or multiple entries (allow_multiple)
                if inputModelQuery['allow_change']['value']:
                    #check if you are in time for the change
                    if inputModelQuery['allow_change']['before'] > datetime.now():
                        #if we successfully decode the string, we need to make sure it is in the right format
                        payload = dict_compare(inputModelQuery['object_model'],payload_to_dict)
                        payload['transaction_modification_date']=datetime.now()
                        inputTransaction.find_one_and_update({"_id":ObjectId(transaction['_id'])},{"$set":payload})
                    else: raise UnicornException(name=payload_to_dict,label="transaction was changeable until "+str(inputModelQuery['allow_change']['before']))
                elif inputModelQuery['allow_multiple']['value']:
                    #change might not be allowed but multiple entries might be
                    payload = dict_compare(inputModelQuery['object_model'],payload_to_dict)
                    #add modelId and user info into the payload
                    payload['objectModelId']=inputModelQuery['_id']
                    payload['user']=loggedInUser
                    payload['transaction_creation_date']=datetime.now()
                    inputTransaction.insert_one(payload)
                    payload.pop("_id")
                    payload.pop("objectModelId")
                else:
                    raise UnicornException(name=payload_to_dict,label="transaction already exists and cannot be modified and multiple entries are not allowed: "+str(transaction))
            else:
                #no transaction was ever recorded with the pair modelId/user
                #if we successfully decode the string, we need to make sure it is in the right format
                payload = dict_compare(inputModelQuery['object_model'],payload_to_dict)
                #add modelId and user info into the payload
                payload['objectModelId']=inputModelQuery['_id']
                payload['user']=loggedInUser
                payload['transaction_creation_date']=datetime.now()
                inputTransaction.insert_one(payload)
                #remove objectIDs after insertion
                payload.pop("_id")
                payload.pop("objectModelId")
                
    else: raise UnicornException(name=objectModelId,label="invalid ObjectIdModel, it must be a 12-byte input or a 24-character hex string")
    

    return {"payload": payload}

@app.get("/unicorns/{name}")
async def read_unicorn(name: str):
    print(loggedInUser)
    if name == "yolo":
        raise UnicornException(name=name)
    return {"unicorn_name": loggedInUser}

def dict_compare(objectModel, payloadModel):

    payload = {}
    #iterating trhough the model's keys and acceptable values
    for k,v in objectModel.items():
        #if key exists in the payload - check that the value is authorized
        if k in payloadModel.keys():
            #if the model attribute is a list, use "in"
            if isinstance(v['values'],list):
                if payloadModel[k] in v['values'] or not v['values']:
                    print("payload "+ str(payloadModel[k]) + " authorized in model")
                    payload[k] = payloadModel[k]
                else: 
                    print("payload "+ str(payloadModel[k]) + " NOT authorized in model, values expected in: "+str(v['values'])+", value received:"+payloadModel[k]+" of type:"+str(type(payloadModel[k])))
                    raise UnicornException(name=payloadModel[k],label="invalid payload, values expected in: "+str(v['values'])+", value received:"+payloadModel[k]+" of type:"+str(type(payloadModel[k])))
            #if not a list, then it is an open type *integer* *datetime*
            else:
                if isinstance(payloadModel[k],eval(v['values'])):
                    print("payload "+ str(payloadModel[k]) + " authorized in model")
                    payload[k] = payloadModel[k]
                else: 
                    print("payload "+ str(payloadModel[k]) + " NOT authorized in model, type expected: "+str(v['values'])+", type received:"+str(type(payloadModel[k])))
                    raise UnicornException(name=payloadModel[k],label="invalid payload, type expected:"+str(v['values'])+", type received:"+str(type(payloadModel[k])))

        else:
            print("no data was pushed for key "+k+". Please review your payload")
            raise UnicornException(name=payloadModel,label="payload not fully matching object model, expected: "+str(objectModel))

    return payload

def dict_compareBU(objectModel, payloadModel):

    #d1_keys = set(d1.keys())
    #print(d1_keys)
    #d2_keys = set(d2.keys())
    #print(d2_keys)
    #intersect_keys = d1_keys.intersection(d2_keys)
    #print(intersect_keys)
    #added = d1_keys - d2_keys
    #print(added)
    #removed = d2_keys - d1_keys
    #print(removed)
    #modified = {o : (d1[o], d2[o]) for o in intersect_keys if d2[o] in d1[o]}
    #print("modified")
    #print(modified)
    #same = set(o for o in intersect_keys if d1[o] == d2[o])
    #print(same)

    return added, removed, modified, same

@app.get("/transactions/{objectModelId}")
def getTransactions(objectModelId: str, request: Request):
    
    try:
        query = inputTransaction.find({"objectModelId": ObjectId(objectModelId)})
        print(list(query))
        print(type(list(query)))
        #for document in query:
        #  print(document)
    except Exception as e:
        print("error")
        print(e)    

    return {"payload":list(query)}


@app.get("/views/transactions/{objectModelId}")
def getTransactionsList(objectModelId: str, request: Request):
    data = {}
    try:
        query = inputTransaction.find({"objectModelId": ObjectId(objectModelId)})
        data['payload']= list(query)
        print(data)
        #for document in query:
        #  print(document)
    except Exception as e:
        print("error")
        print(e)    

    return templates.TemplateResponse("main.html", {"request": request, "payload":data})

#user can get a live feed of the data_stream_id
@app.websocket("/feed/transactions/{objectModelId}")
async def websocket_endpoint(websocket: WebSocket, objectModelId: str):

    await manager.connect(websocket)
    await manager.broadcast(f"transactions #"+str(inputTransaction.count_documents({"objectModelId": ObjectId(objectModelId)})))
    try:
        while True:
            #DS:b43fSxO
            data = await websocket.receive_text()
            #collection.insert_one({'message':data})
            count = inputTransaction.count_documents({"objectModelId": ObjectId(objectModelId)})
            print(count)
            #await manager.broadcast(f"Client #"+feedback_collection.count_documents({}))
            #await manager.send_personal_message(f"You wrote: {data}", websocket)
            await manager.broadcast(f"Client: {count}")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        #await manager.broadcast(f"Current count #{count}"