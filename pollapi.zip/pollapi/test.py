#listOb = ['oo','bb']
listOb = 'ooo'
stringOb = 'oo'

print(stringOb in listOb)