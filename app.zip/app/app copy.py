import tkinter as tk
import time
import win32serviceutil  # ServiceFramework and commandline helper
import win32service  # Events
import win32event  # Events
import servicemanager  # Simple setup and logging
import sys
import server
import os
import subprocess


#root= tk.Tk()
#canvas1 = tk.Canvas(root, width = 300, height = 300)
#canvas1.pack()

#def hello ():  
#    label1 = tk.Label(root, text= 'Hello World!', fg='blue', font=('helvetica', 12, 'bold'))
#    canvas1.create_window(150, 200, window=label1)
    
#button1 = tk.Button(text='Click Me', command=hello, bg='brown',fg='white')
#canvas1.create_window(150, 150, window=button1)



class MyService:
    """Silly little application stub"""
    def stop(self):
        """Stop the service"""
        self.running = False

    def run(self):
        """Main service loop. This is where work is done!"""
        self.running = True
        while self.running:
            time.sleep(10)  # Important work
            servicemanager.LogInfoMsg("Service running...")

   # def kill_proc_tree(pid):
  #      parent = psutil.Process(pid)
   #     children = parent.children(recursive=True)
    #    for child in children:
     #       child.kill()

class MyServiceFramework(win32serviceutil.ServiceFramework):

    _svc_name_ = "FastAPI Uvicorn Server Service"  # service name
    _svc_display_name_ = "FastAPI Uvicorn Server Service"  # service display name
    _svc_description_ = "This service starts up the uvicorn server."  # service description

    def SvcStop(self):
        """Stop the service"""
        #self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        #self.service_impl.stop()
        #self.ReportServiceStatus(win32service.SERVICE_STOPPED)
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        #kill_proc_tree(self.process.pid)
        self.process.terminate()
        win32event.SetEvent(self.hWaitStop)
        self.ReportServiceStatus(win32service.SERVICE_STOPPED)

    def SvcDoRun(self):
        """Start the service; does not return until stopped"""
        #self.ReportServiceStatus(win32service.SERVICE_START_PENDING)
        #self.service_impl = MyService()
        #self.ReportServiceStatus(win32service.SERVICE_RUNNING)
        # Run the service
        #self.service_impl.run()
        server_path = os.path.join(sys._MEIPASS, "server.exe")
        server_cmd = f"call {server_path}"
        self.process = subprocess.Popen(server_cmd, shell=True)
        win32event.WaitForSingleObject(self.hWaitStop   , win32event.INFINITE)


def init():
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(MyServiceFramework)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(MyServiceFramework)


if __name__ == '__main__':
    init()